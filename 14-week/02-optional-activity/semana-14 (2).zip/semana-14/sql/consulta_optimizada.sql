-- =====================================================================
-- Corte 3 · Optimización de consulta SQL
-- Indicador: demanda promedio mensual de 2025 + media móvil de 3 meses
-- Tabla: demanda_diaria(fecha DATE, demanda_gbtud REAL)
-- =====================================================================

-- ---------------------------------------------------------------------
-- VERSIÓN ORIGINAL (lenta)
-- Problemas:
--   1. Función sobre la columna en el WHERE (strftime(fecha)) -> no usa índice
--      (consulta "no sargable"): recorre toda la tabla.
--   2. Subconsulta correlacionada para la media móvil: se re-ejecuta por cada
--      mes y vuelve a escanear la tabla completa cada vez.
-- ---------------------------------------------------------------------
SELECT m.mes,
       m.demanda_media,
       (SELECT AVG(d2.demanda_gbtud)
          FROM demanda_diaria d2
         WHERE strftime('%Y-%m', d2.fecha) BETWEEN
               strftime('%Y-%m', date(m.mes || '-01', '-2 months')) AND m.mes
       ) AS mm_3m
FROM (SELECT strftime('%Y-%m', fecha) AS mes,
             AVG(demanda_gbtud)       AS demanda_media
        FROM demanda_diaria
       WHERE strftime('%Y', fecha) = '2025'
       GROUP BY strftime('%Y-%m', fecha)) m
ORDER BY m.mes;

-- ---------------------------------------------------------------------
-- VERSIÓN OPTIMIZADA
-- Mejoras:
--   1. Índice sobre la columna de fecha.
--   2. Filtro por RANGO (fecha >= ... AND fecha < ...): la columna queda
--      "limpia" y el motor hace búsqueda por índice en lugar de escaneo.
--      Se incluyen oct-nov 2024 para que la media móvil de ene-feb tenga historia.
--   3. Agregación una sola vez en un CTE y media móvil con FUNCIÓN DE VENTANA
--      (AVG OVER ... ROWS 2 PRECEDING) en lugar de subconsulta correlacionada.
--   4. Solo las columnas necesarias (sin SELECT *).
-- Nota: la media móvil queda como promedio de los 3 promedios mensuales.
-- ---------------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_demanda_fecha ON demanda_diaria(fecha);

WITH mensual AS (
    SELECT strftime('%Y-%m', fecha) AS mes,
           AVG(demanda_gbtud)       AS demanda_media
      FROM demanda_diaria
     WHERE fecha >= '2024-11-01' AND fecha < '2026-01-01'
     GROUP BY mes
),
con_mm AS (
    SELECT mes,
           demanda_media,
           AVG(demanda_media) OVER (ORDER BY mes
                                    ROWS BETWEEN 2 PRECEDING AND CURRENT ROW) AS mm_3m
      FROM mensual
)
SELECT mes, ROUND(demanda_media, 1) AS demanda_media, ROUND(mm_3m, 1) AS mm_3m
  FROM con_mm
 WHERE mes >= '2025-01'
 ORDER BY mes;
