"""Carga la serie en SQLite, ejecuta la consulta original y la optimizada,
y compara plan de ejecución y tiempo (promedio de 20 ejecuciones)."""
import sqlite3, time, pathlib, pandas as pd

base = pathlib.Path(__file__).resolve().parent
sql = (base / "consulta_optimizada.sql").read_text(encoding="utf-8")
original = sql.split("-- VERSIÓN ORIGINAL")[1].split("-- VERSIÓN OPTIMIZADA")[0]
original = original[original.index("SELECT"):].strip()
optimizada = sql[sql.index("WITH mensual"):].strip()

con = sqlite3.connect(":memory:")
df = pd.read_csv(base.parent / "data/demanda_gas_diaria.csv")
# Se replica la serie 30 veces (30 "puntos de entrega") para que el volumen sea medible
df = pd.concat([df] * 30, ignore_index=True)
df.to_sql("demanda_diaria", con, index=False)

def medir(q, n=20):
    t0 = time.perf_counter()
    for _ in range(n):
        res = con.execute(q).fetchall()
    return (time.perf_counter() - t0) / n * 1000, res

def plan(q):
    return [r[-1] for r in con.execute("EXPLAIN QUERY PLAN " + q)]

t_orig, r_orig = medir(original)
p_orig = plan(original)
con.execute("CREATE INDEX idx_demanda_fecha ON demanda_diaria(fecha)")
t_opt, r_opt = medir(optimizada)
p_opt = plan(optimizada)

print(f"Filas en la tabla: {len(df):,}")
print(f"\nORIGINAL   : {t_orig:7.2f} ms  | plan: {p_orig}")
print(f"OPTIMIZADA : {t_opt:7.2f} ms  | plan: {p_opt}")
print(f"\nMejora: {t_orig / t_opt:.1f}x más rápida")
print("\nResultado optimizado (mes, demanda media, media móvil 3m):")
for r in r_opt:
    print("  ", r)
