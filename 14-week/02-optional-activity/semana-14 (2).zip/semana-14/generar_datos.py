"""Genera la serie diaria de demanda de gas natural (simulada, reproducible)."""
import numpy as np, pandas as pd
rng = np.random.default_rng(14)
fechas = pd.date_range("2023-01-01", "2025-12-31", freq="D")
t = np.arange(len(fechas))
tendencia = 950 + 0.06 * t                                   # crecimiento lento (GBTUD)
mes = fechas.month
# Temporada seca (dic-mar) y El Niño: mayor despacho térmico
estacional = np.select([mes.isin([12,1,2,3]), mes.isin([7,8])], [90, 35], default=-20)
semanal = np.where(fechas.dayofweek >= 5, -45, 10)           # fines de semana más bajos
ruido = rng.normal(0, 25, len(fechas))
demanda = tendencia + estacional + semanal + ruido
pd.DataFrame({"fecha": fechas, "demanda_gbtud": demanda.round(1)}).to_csv("data/demanda_gas_diaria.csv", index=False)
print(len(fechas), "registros")
