"""
Corte 3 - Análisis temporal y visualización
Serie: demanda diaria de gas natural (GBTUD), ene-2023 a dic-2025.
Pasos: resample mensual -> media móvil -> tendencia y estacionalidad -> 2 gráficas.
"""
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick

# ---------------------------------------------------------------- 1. Carga
df = pd.read_csv("data/demanda_gas_diaria.csv", parse_dates=["fecha"]).set_index("fecha")
s = df["demanda_gbtud"]

# ---------------------------------------------------------------- 2. Resample + media móvil
mensual = s.resample("MS").mean().to_frame("demanda_media")          # promedio mensual
mensual["mm_3m"] = mensual["demanda_media"].rolling(3).mean()         # media móvil 3 meses
mensual["mm_12m"] = mensual["demanda_media"].rolling(12).mean()       # media móvil 12 meses (tendencia)
diaria_mm7 = s.rolling(7).mean()                                      # suaviza el ciclo semanal
anual = s.resample("YS").mean()

# ---------------------------------------------------------------- 3. Tendencia
crec_anual = anual.pct_change() * 100
mm12 = mensual["mm_12m"].dropna()
crec_total = (mm12.iloc[-1] / mm12.iloc[0] - 1) * 100

# ---------------------------------------------------------------- 4. Estacionalidad
idx_mes = s.groupby(s.index.month).mean() / s.mean() * 100            # índice estacional (100 = promedio)
idx_dia = s.groupby(s.index.dayofweek).mean() / s.mean() * 100
seca = s[s.index.month.isin([12, 1, 2, 3])].mean()
resto = s[~s.index.month.isin([12, 1, 2, 3])].mean()

print("== Promedio anual (GBTUD) ==\n", anual.round(1).to_string())
print("\n== Crecimiento anual (%) ==\n", crec_anual.round(2).dropna().to_string())
print(f"\nMedia móvil 12m: {mm12.iloc[0]:.1f} -> {mm12.iloc[-1]:.1f} ({crec_total:+.1f}%)")
print("\n== Índice estacional por mes ==\n", idx_mes.round(1).to_string())
print("\n== Índice por día de semana (0=lunes) ==\n", idx_dia.round(1).to_string())
print(f"\nTemporada seca dic-mar: {seca:.1f} | resto del año: {resto:.1f} | diferencia {seca/resto*100-100:+.1f}%")

mensual.round(1).to_csv("data/demanda_mensual_resample.csv")

# ---------------------------------------------------------------- 5. Visualizaciones
GRIS, AZUL, ACENTO = "#9aa0a6", "#1f4e79", "#c0504d"
plt.rcParams.update({"font.family": "DejaVu Sans", "axes.spines.top": False,
                     "axes.spines.right": False, "axes.titleweight": "bold"})

# Gráfica 1 - EVOLUCIÓN
fig, ax = plt.subplots(figsize=(11, 5.2))
ax.plot(diaria_mm7.index, diaria_mm7, color=GRIS, lw=0.8, alpha=0.7, label="Media móvil 7 días")
ax.plot(mensual.index, mensual["demanda_media"], "o-", color=AZUL, lw=1.6, ms=4, label="Promedio mensual (resample)")
ax.plot(mensual.index, mensual["mm_12m"], color=ACENTO, lw=2.6, label="Media móvil 12 meses (tendencia)")
for y in [2023, 2024, 2025]:
    ax.axvspan(pd.Timestamp(f"{y}-01-01"), pd.Timestamp(f"{y}-03-31"), color=AZUL, alpha=0.06)
ax.axvspan(pd.Timestamp("2025-12-01"), pd.Timestamp("2025-12-31"), color=AZUL, alpha=0.06)
ax.set_ylim(0, None)                                   # eje honesto: inicia en cero
ax.yaxis.set_major_formatter(mtick.StrMethodFormatter("{x:,.0f}"))
ax.set_ylabel("Demanda (GBTUD)")
ax.set_title(f"La demanda de gas crece {crec_total:.0f}% en tendencia y sube cada temporada seca (dic–mar)", loc="left", fontsize=12.5)
ax.text(0, -0.13, "Franjas sombreadas: temporada seca. Fuente: datos simulados para el ejercicio.",
        transform=ax.transAxes, fontsize=8.5, color="#555")
ax.legend(frameon=False, loc="lower right", fontsize=9)
ax.grid(axis="y", alpha=0.25)
fig.tight_layout(); fig.savefig("img/01_evolucion_demanda.png", dpi=160); plt.close(fig)

# Gráfica 2 - COMPARACIÓN (perfil estacional por mes)
nombres = ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"]
prom_mes = s.groupby(s.index.month).mean()
colores = [AZUL if m in (12, 1, 2, 3) else GRIS for m in prom_mes.index]
fig, ax = plt.subplots(figsize=(11, 5.2))
barras = ax.bar(nombres, prom_mes.values, color=colores, width=0.7)
ax.axhline(s.mean(), color=ACENTO, ls="--", lw=1.2)
ax.text(4, s.mean() + 12, f"Promedio general {s.mean():,.0f}", color=ACENTO, ha="center", fontsize=9,
        bbox=dict(facecolor="white", edgecolor="none", pad=1))
ax.bar_label(barras, fmt="{:,.0f}", fontsize=8.5, padding=2)
ax.set_ylim(0, prom_mes.max() * 1.12)                   # barras siempre desde cero
ax.set_ylabel("Demanda promedio diaria (GBTUD)")
ax.set_title(f"Dic–mar consume {seca/resto*100-100:.0f}% más gas que el resto del año", loc="left", fontsize=12.5)
ax.text(0, -0.12, "Promedio 2023–2025 por mes. Azul: temporada seca. Fuente: datos simulados para el ejercicio.",
        transform=ax.transAxes, fontsize=8.5, color="#555")
ax.grid(axis="y", alpha=0.25)
fig.tight_layout(); fig.savefig("img/02_comparacion_mensual.png", dpi=160); plt.close(fig)
print("\nGráficas guardadas en img/")
