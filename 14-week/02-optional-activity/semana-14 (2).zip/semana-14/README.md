# Corte 3 · Análisis temporal y visualización (Semana 14)

**Autor:** Gener Valencia
**Tema:** Demanda diaria de gas natural (GBTUD), enero 2023 – diciembre 2025
**Herramientas:** Python (pandas, matplotlib) · SQL (SQLite)

> Los datos son **simulados y reproducibles** (`generar_datos.py`, semilla fija) con un comportamiento realista del mercado de gas: tendencia creciente, mayor consumo térmico en la temporada seca (dic–mar), un repunte a mitad de año y menor consumo los fines de semana.

---

## Estructura de la carpeta

```
semana-14/
├── README.md
├── requirements.txt
├── generar_datos.py              # crea la serie diaria
├── analisis_serie_temporal.py    # resample + media móvil + gráficas
├── salida_analisis.txt           # resultados impresos del análisis
├── data/
│   ├── demanda_gas_diaria.csv        # 1.096 registros diarios
│   └── demanda_mensual_resample.csv  # serie mensual + medias móviles
├── img/
│   ├── 01_evolucion_demanda.png      # gráfica de evolución
│   └── 02_comparacion_mensual.png    # gráfica de comparación
└── sql/
    ├── consulta_optimizada.sql       # consulta original vs optimizada
    ├── prueba_optimizacion.py        # mide tiempos y planes de ejecución
    └── resultado_prueba.txt
```

**Cómo ejecutar:**
```bash
pip install -r requirements.txt
python generar_datos.py
python analisis_serie_temporal.py
python sql/prueba_optimizacion.py
```

---

## 1. Serie temporal: resample y media móvil

| Paso | Código | Para qué |
|---|---|---|
| Agregación mensual | `s.resample("MS").mean()` | Pasa de 1.096 días a 36 meses |
| Media móvil 7 días | `s.rolling(7).mean()` | Elimina el ciclo semanal |
| Media móvil 3 meses | `mensual.rolling(3).mean()` | Suaviza el ruido mensual |
| Media móvil 12 meses | `mensual.rolling(12).mean()` | Elimina la estacionalidad → deja la **tendencia** |
| Índice estacional | promedio por mes ÷ promedio general × 100 | Mide la **estacionalidad** |

**Resultados clave**

| Indicador | Valor |
|---|---|
| Promedio anual 2023 / 2024 / 2025 | 982,5 / 1.002,2 / 1.022,7 GBTUD |
| Crecimiento anual | +2,0 % (2024) y +2,0 % (2025) |
| Media móvil 12 m (dic-2023 → dic-2025) | 982,4 → 1.022,6 GBTUD (**+4,1 %**) |
| Temporada seca (dic–mar) vs resto del año | 1.063,0 vs 972,3 GBTUD (**+9,3 %**) |
| Mes pico / mes valle (índice) | Diciembre 107,6 / Abril 94,9 |
| Fin de semana vs entre semana (índice) | 96,2 vs ~101,5 |

**Interpretación**
- **Tendencia:** creciente y estable, alrededor de 2 % anual. La media móvil de 12 meses es casi una línea recta, lo que indica crecimiento sostenido y no saltos puntuales.
- **Estacionalidad anual:** se repite cada año. Dic–mar está 5–8 % por encima del promedio (mayor despacho térmico en temporada seca); abril–junio y sep–nov están 3–5 % por debajo; julio–agosto muestra un repunte moderado (+1 %).
- **Estacionalidad semanal:** sábados y domingos consumen ~5 % menos que los días hábiles, por menor actividad industrial.

---

## 2. Visualizaciones

### Evolución
![Evolución de la demanda](img/01_evolucion_demanda.png)

### Comparación
![Comparación por mes](img/02_comparacion_mensual.png)

**Principios aplicados**
- **Título que expresa la conclusión**, no solo el tema ("crece 4 %", "dic–mar consume 9 % más").
- **Ejes honestos:** ambos ejes Y inician en **cero**, así las diferencias no se exageran visualmente; unidades en el eje (GBTUD) y separador de miles.
- **Tipo de gráfica adecuado:** líneas para evolución en el tiempo; barras para comparar categorías (meses).
- **Color con significado:** azul solo para la temporada seca; gris para el resto; rojo para la tendencia y el promedio de referencia.
- **Contexto:** fuente y nota en el pie; franjas sombreadas marcan la temporada seca; sin bordes ni decoración innecesaria.

---

## 3. Optimización de consulta SQL

Indicador: **demanda promedio mensual de 2025 con su media móvil de 3 meses** (`sql/consulta_optimizada.sql`).

| Problema en la consulta original | Solución en la optimizada |
|---|---|
| `WHERE strftime('%Y', fecha) = '2025'`: función sobre la columna → el motor no puede usar índice y recorre toda la tabla | Filtro por rango `fecha >= '2024-11-01' AND fecha < '2026-01-01'` + **índice** `idx_demanda_fecha` |
| Media móvil con **subconsulta correlacionada**: se ejecuta una vez por cada mes y escanea la tabla completa cada vez | Se agrega una sola vez (CTE) y la media móvil se calcula con **función de ventana** `AVG() OVER (ROWS BETWEEN 2 PRECEDING AND CURRENT ROW)` |
| Agrupaciones y cálculos repetidos | CTE legibles y reutilizables, solo columnas necesarias |

**Prueba real (SQLite, 32.880 filas, promedio de 20 ejecuciones):**

| Versión | Plan de ejecución | Tiempo |
|---|---|---|
| Original | `SCAN demanda_diaria` + `CORRELATED SCALAR SUBQUERY` → `SCAN d2` | 172,4 ms |
| Optimizada | `SEARCH demanda_diaria USING INDEX idx_demanda_fecha (fecha>? AND fecha<?)` | 5,1 ms |

**Resultado: ~34 veces más rápida.** El plan confirma el cambio de *SCAN* (lectura completa) a *SEARCH* por índice, y la desaparición de la subconsulta correlacionada. La mejora crece con el volumen de datos, porque la versión original escala aproximadamente como *meses × filas*, mientras que la optimizada lee solo el rango necesario una vez.

---

## Findings

The daily natural gas demand series shows a clear upward trend: the 12-month moving average rose from 982 to 1,023 GBTUD between December 2023 and December 2025, an increase of about 4.1%, or roughly 2% per year. The series also has a strong annual seasonality that repeats every year, with demand during the dry season (December to March) about 9% higher than in the rest of the year, mainly because of higher thermal power generation. December is the peak month (index 107.6) and April is the lowest (index 94.9), while July and August show a smaller mid-year increase. There is also a weekly pattern, since weekends consume about 5% less gas than weekdays. The first chart (evolution) shows the monthly average obtained with resample, the 7-day moving average, and the 12-month moving average, so the reader can see the steady trend and the repeated dry-season peaks at the same time. The second chart (comparison) shows the average daily demand for each month on a zero-based axis, with the dry-season months highlighted in blue and a reference line for the overall average. Together, both charts suggest that supply and contracts should be planned with extra volume for December to March and with a yearly growth margin of about 2%.
